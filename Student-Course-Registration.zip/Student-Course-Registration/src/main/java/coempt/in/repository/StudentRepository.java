package coempt.in.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import coempt.in.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
	Student findByEmail(String email);
}