package coempt.in.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import coempt.in.entity.Registration;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {
	List<Registration> findByStudentId(Long studentId);
}

