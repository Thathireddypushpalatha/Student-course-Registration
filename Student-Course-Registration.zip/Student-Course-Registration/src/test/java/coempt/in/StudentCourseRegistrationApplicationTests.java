package coempt.in;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentCourseRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
