package coempt.in.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import coempt.in.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {
	Admin findByUsername(String username);
}
