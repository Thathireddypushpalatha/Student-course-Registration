package coempt.in.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import coempt.in.entity.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
