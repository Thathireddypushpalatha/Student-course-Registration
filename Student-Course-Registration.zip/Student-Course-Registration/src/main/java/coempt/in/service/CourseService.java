package coempt.in.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import coempt.in.entity.Course;
import coempt.in.repository.CourseRepository;

@Service
public class CourseService {
	@Autowired
	private CourseRepository courseRepository;

	

	// Get all courses
	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	// Save a new course
	public Course save(Course course) {
		return courseRepository.save(course);
	}

	// Get a course by ID
	public Course getCourseById(Long id) {
		Course Course = courseRepository.findById(id).get();
		return Course; // Return null if not found
	}

	// Delete a course by ID
	public void deleteCourse(Long id) {
		courseRepository.deleteById(id);
	}


	
}
